/**
 * Torvia Dashboard Management System
 * Handles dashboard functionality for contractors, subcontractors, and clients
 */

class TorviaDashboard {
    constructor() {
        this.currentUser = null;
        this.dashboardType = null;
        this.activeProjects = [];
        this.init();
    }

    init() {
        this.loadUserData();
        this.setupEventListeners();
        this.initializeWidgets();
    }

    loadUserData() {
        // Load user data from localStorage or API
        const userData = localStorage.getItem('torvia_user');
        if (userData) {
            this.currentUser = JSON.parse(userData);
            this.dashboardType = this.currentUser.type; // contractor, subcontractor, client
            this.renderDashboard();
        }
    }

    setupEventListeners() {
        // Project management events
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('project-action-btn')) {
                this.handleProjectAction(e.target.dataset.action, e.target.dataset.projectId);
            }
            
            if (e.target.classList.contains('dashboard-tab')) {
                this.switchTab(e.target.dataset.tab);
            }

            if (e.target.classList.contains('notification-item')) {
                this.markNotificationRead(e.target.dataset.notificationId);
            }
        });

        // Real-time updates
        this.setupWebSocketConnection();
    }

    renderDashboard() {
        const dashboardContainer = document.getElementById('dashboard-content');
        if (!dashboardContainer) return;

        let dashboardHTML = '';

        switch (this.dashboardType) {
            case 'contractor':
                dashboardHTML = this.renderContractorDashboard();
                break;
            case 'subcontractor':
                dashboardHTML = this.renderSubcontractorDashboard();
                break;
            case 'client':
                dashboardHTML = this.renderClientDashboard();
                break;
            default:
                dashboardHTML = this.renderDefaultDashboard();
        }

        dashboardContainer.innerHTML = dashboardHTML;
        this.initializeCharts();
    }

    renderContractorDashboard() {
        return `
            <div class="dashboard-overview">
                <div class="stats-grid grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Aktive Projekte</h3>
                        <p class="text-3xl font-bold text-blue-600">${this.getActiveProjectsCount()}</p>
                    </div>
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Ausstehende Angebote</h3>
                        <p class="text-3xl font-bold text-orange-600">${this.getPendingBidsCount()}</p>
                    </div>
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Monatlicher Umsatz</h3>
                        <p class="text-3xl font-bold text-green-600">€${this.getMonthlyRevenue()}</p>
                    </div>
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Bewertung</h3>
                        <p class="text-3xl font-bold text-yellow-600">${this.getCurrentRating()}/5</p>
                    </div>
                </div>
                
                <div class="dashboard-tabs">
                    <nav class="flex space-x-4 mb-6">
                        <button class="dashboard-tab active" data-tab="projects">Projekte</button>
                        <button class="dashboard-tab" data-tab="calendar">Kalender</button>
                        <button class="dashboard-tab" data-tab="finances">Finanzen</button>
                        <button class="dashboard-tab" data-tab="team">Team</button>
                    </nav>
                    
                    <div id="tab-content">
                        ${this.renderProjectsTab()}
                    </div>
                </div>
            </div>
        `;
    }

    renderSubcontractorDashboard() {
        return `
            <div class="dashboard-overview">
                <div class="stats-grid grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Verfügbare Jobs</h3>
                        <p class="text-3xl font-bold text-blue-600">${this.getAvailableJobsCount()}</p>
                    </div>
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Aktuelle Aufträge</h3>
                        <p class="text-3xl font-bold text-green-600">${this.getCurrentJobsCount()}</p>
                    </div>
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Verdienst diese Woche</h3>
                        <p class="text-3xl font-bold text-green-600">€${this.getWeeklyEarnings()}</p>
                    </div>
                </div>
                
                <div class="job-opportunities bg-white p-6 rounded-lg shadow mb-6">
                    <h3 class="text-xl font-semibold mb-4">Neue Jobmöglichkeiten</h3>
                    <div id="job-list">
                        ${this.renderJobOpportunities()}
                    </div>
                </div>
            </div>
        `;
    }

    renderClientDashboard() {
        return `
            <div class="dashboard-overview">
                <div class="stats-grid grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Aktive Projekte</h3>
                        <p class="text-3xl font-bold text-blue-600">${this.getClientActiveProjects()}</p>
                    </div>
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Eingegangene Angebote</h3>
                        <p class="text-3xl font-bold text-orange-600">${this.getReceivedBids()}</p>
                    </div>
                    <div class="stat-card bg-white p-6 rounded-lg shadow">
                        <h3 class="text-lg font-semibold text-gray-800">Budget verwendet</h3>
                        <p class="text-3xl font-bold text-green-600">€${this.getUsedBudget()}</p>
                    </div>
                </div>
                
                <div class="project-management bg-white p-6 rounded-lg shadow">
                    <h3 class="text-xl font-semibold mb-4">Meine Projekte</h3>
                    <div id="client-projects">
                        ${this.renderClientProjects()}
                    </div>
                </div>
            </div>
        `;
    }

    handleProjectAction(action, projectId) {
        switch (action) {
            case 'view':
                this.viewProject(projectId);
                break;
            case 'edit':
                this.editProject(projectId);
                break;
            case 'complete':
                this.completeProject(projectId);
                break;
            case 'bid':
                this.placeBid(projectId);
                break;
        }
    }

    switchTab(tabName) {
        // Remove active class from all tabs
        document.querySelectorAll('.dashboard-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Add active class to clicked tab
        event.target.classList.add('active');
        
        // Render tab content
        const tabContent = document.getElementById('tab-content');
        switch (tabName) {
            case 'projects':
                tabContent.innerHTML = this.renderProjectsTab();
                break;
            case 'calendar':
                tabContent.innerHTML = this.renderCalendarTab();
                break;
            case 'finances':
                tabContent.innerHTML = this.renderFinancesTab();
                break;
            case 'team':
                tabContent.innerHTML = this.renderTeamTab();
                break;
        }
    }

    initializeWidgets() {
        // Initialize dashboard widgets
        this.initializeNotifications();
        this.initializeQuickActions();
        this.setupProgressTracking();
    }

    initializeCharts() {
        // Initialize revenue charts, project progress charts, etc.
        if (typeof Chart !== 'undefined') {
            this.renderRevenueChart();
            this.renderProjectStatusChart();
        }
    }

    setupWebSocketConnection() {
        // Setup real-time updates for dashboard
        if (typeof WebSocket !== 'undefined') {
            this.ws = new WebSocket('wss://api.torvia.de/dashboard-updates');
            this.ws.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleRealtimeUpdate(data);
            };
        }
    }

    // Helper methods
    getActiveProjectsCount() { return this.activeProjects.length || 12; }
    getPendingBidsCount() { return 5; }
    getMonthlyRevenue() { return '15,240'; }
    getCurrentRating() { return 4.8; }
    getAvailableJobsCount() { return 8; }
    getCurrentJobsCount() { return 3; }
    getWeeklyEarnings() { return '1,250'; }
    getClientActiveProjects() { return 2; }
    getReceivedBids() { return 7; }
    getUsedBudget() { return '8,500'; }

    renderProjectsTab() {
        return `<div class="projects-tab-content">Projekte werden geladen...</div>`;
    }

    renderCalendarTab() {
        return `<div class="calendar-tab-content">Kalender wird geladen...</div>`;
    }

    renderFinancesTab() {
        return `<div class="finances-tab-content">Finanzen werden geladen...</div>`;
    }

    renderTeamTab() {
        return `<div class="team-tab-content">Team-Übersicht wird geladen...</div>`;
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('dashboard-content')) {
        new TorviaDashboard();
    }
});

// Export for module usage
window.TorviaDashboard = TorviaDashboard;