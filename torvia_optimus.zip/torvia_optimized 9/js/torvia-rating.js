/**
 * Torvia Rating and Review System
 * Handles ratings, reviews, and feedback management
 */

class TorviaRating {
    constructor() {
        this.ratings = [];
        this.currentRating = 0;
        this.reviewMode = 'display'; // display, create, edit
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadExistingRatings();
        this.initializeRatingComponents();
    }

    setupEventListeners() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('star-rating')) {
                this.handleStarClick(e.target);
            }
            
            if (e.target.classList.contains('submit-review-btn')) {
                this.submitReview(e.target.dataset.providerId);
            }
            
            if (e.target.classList.contains('show-all-reviews')) {
                this.showAllReviews(e.target.dataset.providerId);
            }

            if (e.target.classList.contains('helpful-btn')) {
                this.markReviewHelpful(e.target.dataset.reviewId);
            }

            if (e.target.classList.contains('report-review-btn')) {
                this.reportReview(e.target.dataset.reviewId);
            }
        });

        document.addEventListener('mouseover', (e) => {
            if (e.target.classList.contains('star-rating')) {
                this.highlightStars(e.target);
            }
        });

        document.addEventListener('mouseout', (e) => {
            if (e.target.classList.contains('star-rating')) {
                this.resetStarHighlight();
            }
        });
    }

    initializeRatingComponents() {
        // Initialize all rating displays on the page
        document.querySelectorAll('.rating-display').forEach(display => {
            this.renderRatingDisplay(display);
        });

        // Initialize rating input forms
        document.querySelectorAll('.rating-input').forEach(input => {
            this.renderRatingInput(input);
        });

        // Initialize review sections
        document.querySelectorAll('.reviews-section').forEach(section => {
            this.renderReviewsSection(section);
        });
    }

    renderRatingDisplay(container) {
        const rating = parseFloat(container.dataset.rating) || 0;
        const reviewCount = parseInt(container.dataset.reviewCount) || 0;
        const showDetails = container.dataset.showDetails === 'true';

        const starsHTML = this.generateStarsHTML(rating, false);
        
        let html = `
            <div class="rating-display-content">
                <div class="stars-container">
                    ${starsHTML}
                </div>
                <div class="rating-info">
                    <span class="rating-value">${rating.toFixed(1)}</span>
                    <span class="review-count">(${reviewCount} Bewertungen)</span>
                </div>
            </div>
        `;

        if (showDetails) {
            html += this.renderRatingBreakdown(container.dataset.providerId);
        }

        container.innerHTML = html;
    }

    renderRatingInput(container) {
        const providerId = container.dataset.providerId;
        const projectId = container.dataset.projectId;

        const html = `
            <div class="rating-input-form">
                <h4 class="mb-4 text-lg font-semibold">Bewerten Sie ${container.dataset.providerName}</h4>
                
                <div class="rating-categories">
                    <div class="rating-category mb-4">
                        <label class="block mb-2">Qualität der Arbeit</label>
                        <div class="star-input-group" data-category="quality">
                            ${this.generateStarsHTML(0, true)}
                        </div>
                    </div>
                    
                    <div class="rating-category mb-4">
                        <label class="block mb-2">Pünktlichkeit</label>
                        <div class="star-input-group" data-category="punctuality">
                            ${this.generateStarsHTML(0, true)}
                        </div>
                    </div>
                    
                    <div class="rating-category mb-4">
                        <label class="block mb-2">Kommunikation</label>
                        <div class="star-input-group" data-category="communication">
                            ${this.generateStarsHTML(0, true)}
                        </div>
                    </div>
                    
                    <div class="rating-category mb-4">
                        <label class="block mb-2">Preis-Leistung</label>
                        <div class="star-input-group" data-category="value">
                            ${this.generateStarsHTML(0, true)}
                        </div>
                    </div>
                </div>
                
                <div class="review-text-section mb-4">
                    <label class="block mb-2">Ihre Bewertung (optional)</label>
                    <textarea 
                        class="review-textarea w-full p-3 border rounded-lg" 
                        rows="4" 
                        placeholder="Teilen Sie Ihre Erfahrungen mit anderen..."
                    ></textarea>
                </div>
                
                <div class="rating-actions">
                    <button 
                        class="submit-review-btn bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
                        data-provider-id="${providerId}"
                        data-project-id="${projectId}"
                    >
                        Bewertung abgeben
                    </button>
                </div>
            </div>
        `;

        container.innerHTML = html;
    }

    renderReviewsSection(container) {
        const providerId = container.dataset.providerId;
        const reviews = this.getReviewsForProvider(providerId);
        
        let html = `
            <div class="reviews-header mb-6">
                <h3 class="text-xl font-semibold">Kundenbewertungen</h3>
                ${this.renderRatingBreakdown(providerId)}
            </div>
            
            <div class="reviews-list">
        `;

        reviews.slice(0, 3).forEach(review => {
            html += this.renderSingleReview(review);
        });

        if (reviews.length > 3) {
            html += `
                <div class="show-more-reviews text-center mt-6">
                    <button 
                        class="show-all-reviews text-blue-600 hover:text-blue-800"
                        data-provider-id="${providerId}"
                    >
                        Alle ${reviews.length} Bewertungen anzeigen
                    </button>
                </div>
            `;
        }

        html += `</div>`;
        container.innerHTML = html;
    }

    renderSingleReview(review) {
        return `
            <div class="review-item bg-gray-50 p-6 rounded-lg mb-4">
                <div class="review-header flex justify-between items-start mb-3">
                    <div class="reviewer-info">
                        <div class="reviewer-name font-semibold">${review.reviewerName}</div>
                        <div class="review-date text-gray-500 text-sm">${this.formatDate(review.date)}</div>
                    </div>
                    <div class="review-rating">
                        ${this.generateStarsHTML(review.overallRating, false)}
                    </div>
                </div>
                
                <div class="review-categories mb-3">
                    <div class="category-ratings grid grid-cols-2 gap-4 text-sm">
                        <div>Qualität: ${this.generateStarsHTML(review.quality, false, 'small')}</div>
                        <div>Pünktlichkeit: ${this.generateStarsHTML(review.punctuality, false, 'small')}</div>
                        <div>Kommunikation: ${this.generateStarsHTML(review.communication, false, 'small')}</div>
                        <div>Preis-Leistung: ${this.generateStarsHTML(review.value, false, 'small')}</div>
                    </div>
                </div>
                
                ${review.comment ? `
                    <div class="review-comment mb-3">
                        <p class="text-gray-700">${review.comment}</p>
                    </div>
                ` : ''}
                
                <div class="review-actions flex items-center space-x-4 text-sm">
                    <button 
                        class="helpful-btn text-gray-600 hover:text-blue-600"
                        data-review-id="${review.id}"
                    >
                        👍 Hilfreich (${review.helpfulCount || 0})
                    </button>
                    <button 
                        class="report-review-btn text-gray-600 hover:text-red-600"
                        data-review-id="${review.id}"
                    >
                        Melden
                    </button>
                </div>
            </div>
        `;
    }

    renderRatingBreakdown(providerId) {
        const stats = this.getRatingStats(providerId);
        
        return `
            <div class="rating-breakdown bg-white p-4 rounded-lg border">
                <div class="overall-rating flex items-center mb-4">
                    <div class="rating-number text-3xl font-bold mr-4">${stats.average.toFixed(1)}</div>
                    <div class="rating-details">
                        ${this.generateStarsHTML(stats.average, false)}
                        <div class="total-reviews text-gray-600">${stats.total} Bewertungen</div>
                    </div>
                </div>
                
                <div class="rating-bars">
                    ${[5,4,3,2,1].map(star => `
                        <div class="rating-bar flex items-center mb-2">
                            <span class="star-label w-8">${star}★</span>
                            <div class="bar-container bg-gray-200 rounded-full h-2 flex-1 mx-3">
                                <div 
                                    class="bar-fill bg-yellow-400 h-2 rounded-full" 
                                    style="width: ${stats.breakdown[star] || 0}%"
                                ></div>
                            </div>
                            <span class="count w-8 text-sm text-gray-600">${stats.counts[star] || 0}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }

    generateStarsHTML(rating, interactive = false, size = 'normal') {
        const sizeClass = size === 'small' ? 'text-sm' : 'text-lg';
        let starsHTML = '';
        
        for (let i = 1; i <= 5; i++) {
            const filled = rating >= i;
            const halfFilled = rating >= (i - 0.5) && rating < i;
            
            let starClass = `star ${sizeClass}`;
            if (interactive) starClass += ' star-rating cursor-pointer';
            if (filled) starClass += ' text-yellow-400';
            else if (halfFilled) starClass += ' text-yellow-300';
            else starClass += ' text-gray-300';
            
            starsHTML += `<span class="${starClass}" data-rating="${i}">★</span>`;
        }
        
        return `<div class="stars-group">${starsHTML}</div>`;
    }

    handleStarClick(starElement) {
        const rating = parseInt(starElement.dataset.rating);
        const category = starElement.closest('.star-input-group')?.dataset.category;
        const starsGroup = starElement.closest('.stars-group');
        
        // Update visual feedback
        this.updateStarVisual(starsGroup, rating);
        
        // Store the rating
        if (category) {
            this.setRatingForCategory(category, rating);
        }
    }

    updateStarVisual(starsGroup, rating) {
        const stars = starsGroup.querySelectorAll('.star');
        stars.forEach((star, index) => {
            if (index < rating) {
                star.classList.add('text-yellow-400');
                star.classList.remove('text-gray-300');
            } else {
                star.classList.remove('text-yellow-400');
                star.classList.add('text-gray-300');
            }
        });
    }

    setRatingForCategory(category, rating) {
        if (!this.currentRating) this.currentRating = {};
        this.currentRating[category] = rating;
    }

    submitReview(providerId) {
        const container = document.querySelector(`[data-provider-id="${providerId}"]`);
        const reviewText = container.querySelector('.review-textarea').value;
        
        // Calculate overall rating
        const categories = ['quality', 'punctuality', 'communication', 'value'];
        let totalRating = 0;
        let ratedCategories = 0;
        
        categories.forEach(category => {
            if (this.currentRating && this.currentRating[category]) {
                totalRating += this.currentRating[category];
                ratedCategories++;
            }
        });
        
        if (ratedCategories === 0) {
            alert('Bitte bewerten Sie mindestens eine Kategorie.');
            return;
        }
        
        const overallRating = totalRating / ratedCategories;
        
        const reviewData = {
            providerId: providerId,
            ratings: this.currentRating,
            overallRating: overallRating,
            comment: reviewText,
            date: new Date().toISOString(),
            reviewerId: this.getCurrentUserId()
        };
        
        this.saveReview(reviewData);
    }

    saveReview(reviewData) {
        // Save to localStorage or send to API
        const reviews = JSON.parse(localStorage.getItem('torvia_reviews') || '[]');
        reviewData.id = Date.now().toString();
        reviews.push(reviewData);
        localStorage.setItem('torvia_reviews', JSON.stringify(reviews));
        
        // Show success message
        this.showSuccessMessage('Bewertung erfolgreich abgegeben!');
        
        // Reset form
        this.currentRating = {};
        
        // Refresh reviews display
        setTimeout(() => {
            location.reload();
        }, 1500);
    }

    getReviewsForProvider(providerId) {
        const reviews = JSON.parse(localStorage.getItem('torvia_reviews') || '[]');
        return reviews.filter(review => review.providerId === providerId);
    }

    getRatingStats(providerId) {
        const reviews = this.getReviewsForProvider(providerId);
        
        if (reviews.length === 0) {
            return { average: 0, total: 0, breakdown: {}, counts: {} };
        }
        
        const total = reviews.length;
        const sum = reviews.reduce((acc, review) => acc + review.overallRating, 0);
        const average = sum / total;
        
        const breakdown = {};
        const counts = {};
        
        [1,2,3,4,5].forEach(star => {
            const count = reviews.filter(review => Math.round(review.overallRating) === star).length;
            counts[star] = count;
            breakdown[star] = (count / total) * 100;
        });
        
        return { average, total, breakdown, counts };
    }

    markReviewHelpful(reviewId) {
        // Implementation for marking review as helpful
        console.log('Marking review as helpful:', reviewId);
    }

    reportReview(reviewId) {
        // Implementation for reporting inappropriate review
        console.log('Reporting review:', reviewId);
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('de-DE');
    }

    getCurrentUserId() {
        const user = JSON.parse(localStorage.getItem('torvia_user') || '{}');
        return user.id || 'anonymous';
    }

    showSuccessMessage(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'fixed top-4 right-4 bg-green-500 text-white p-4 rounded-lg z-50';
        messageDiv.textContent = message;
        document.body.appendChild(messageDiv);
        
        setTimeout(() => {
            messageDiv.remove();
        }, 3000);
    }

    loadExistingRatings() {
        // Load ratings from localStorage or API
        const ratings = localStorage.getItem('torvia_ratings');
        if (ratings) {
            this.ratings = JSON.parse(ratings);
        }
    }
}

// Initialize rating system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.rating-display, .rating-input, .reviews-section')) {
        new TorviaRating();
    }
});

// Export for module usage
window.TorviaRating = TorviaRating;