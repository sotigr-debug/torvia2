/**
 * Torvia B2B Components Library
 * Reusable UI components for the Torvia platform
 */

class TorviaComponents {
    constructor() {
        this.components = new Map();
        this.init();
    }

    init() {
        this.registerComponents();
        this.setupGlobalEventListeners();
        this.initializeExistingComponents();
    }

    registerComponents() {
        // Register all available components
        this.components.set('modal', this.createModal);
        this.components.set('dropdown', this.createDropdown);
        this.components.set('tabs', this.createTabs);
        this.components.set('accordion', this.createAccordion);
        this.components.set('slider', this.createSlider);
        this.components.set('datepicker', this.createDatepicker);
        this.components.set('form-validator', this.createFormValidator);
        this.components.set('notification', this.createNotification);
        this.components.set('progress-bar', this.createProgressBar);
        this.components.set('file-uploader', this.createFileUploader);
    }

    setupGlobalEventListeners() {
        document.addEventListener('click', (e) => {
            // Modal triggers
            if (e.target.dataset.modal) {
                this.openModal(e.target.dataset.modal);
            }
            
            // Dropdown triggers
            if (e.target.classList.contains('dropdown-trigger')) {
                this.toggleDropdown(e.target);
            }
            
            // Tab triggers
            if (e.target.classList.contains('tab-trigger')) {
                this.switchTab(e.target);
            }
            
            // Accordion triggers
            if (e.target.classList.contains('accordion-header')) {
                this.toggleAccordion(e.target);
            }
            
            // Close on outside click
            if (!e.target.closest('.dropdown-content')) {
                this.closeAllDropdowns();
            }
        });

        // ESC key handling
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
                this.closeAllDropdowns();
            }
        });
    }

    initializeExistingComponents() {
        // Auto-initialize components marked with data attributes
        document.querySelectorAll('[data-component]').forEach(element => {
            const componentType = element.dataset.component;
            if (this.components.has(componentType)) {
                const component = this.components.get(componentType);
                component.call(this, element);
            }
        });
    }

    // Modal Component
    createModal(config = {}) {
        const modalId = config.id || 'torvia-modal';
        const size = config.size || 'medium';
        const closable = config.closable !== false;
        
        const modalHTML = `
            <div id="${modalId}" class="modal fixed inset-0 z-50 hidden">
                <div class="modal-overlay absolute inset-0 bg-black opacity-50"></div>
                <div class="modal-container relative z-10 mx-auto mt-20 max-w-${size} bg-white rounded-lg shadow-xl">
                    ${closable ? `
                        <button class="modal-close absolute top-4 right-4 text-gray-400 hover:text-gray-600">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    ` : ''}
                    <div class="modal-header p-6 border-b">
                        <h3 class="modal-title text-lg font-semibold">${config.title || 'Modal'}</h3>
                    </div>
                    <div class="modal-body p-6">
                        ${config.content || 'Modal content goes here...'}
                    </div>
                    <div class="modal-footer p-6 border-t bg-gray-50 rounded-b-lg">
                        ${config.footer || `
                            <div class="flex justify-end space-x-3">
                                <button class="modal-cancel btn-secondary">Abbrechen</button>
                                <button class="modal-confirm btn-primary">Bestätigen</button>
                            </div>
                        `}
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if it exists
        const existingModal = document.getElementById(modalId);
        if (existingModal) {
            existingModal.remove();
        }
        
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Setup event listeners
        const modal = document.getElementById(modalId);
        if (closable) {
            modal.querySelector('.modal-close').addEventListener('click', () => {
                this.closeModal(modalId);
            });
            modal.querySelector('.modal-overlay').addEventListener('click', () => {
                this.closeModal(modalId);
            });
        }
        
        return modal;
    }

    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
    }

    closeModal(modalId = null) {
        if (modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.classList.add('hidden');
            }
        } else {
            // Close all modals
            document.querySelectorAll('.modal').forEach(modal => {
                modal.classList.add('hidden');
            });
        }
        document.body.style.overflow = '';
    }

    // Dropdown Component
    createDropdown(element) {
        const dropdownHTML = `
            <div class="dropdown relative">
                <button class="dropdown-trigger flex items-center space-x-2 px-4 py-2 bg-white border rounded-lg hover:bg-gray-50">
                    <span>${element.dataset.label || 'Dropdown'}</span>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                    </svg>
                </button>
                <div class="dropdown-content absolute top-full left-0 mt-1 w-48 bg-white border rounded-lg shadow-lg z-20 hidden">
                    ${element.innerHTML}
                </div>
            </div>
        `;
        
        element.innerHTML = dropdownHTML;
    }

    toggleDropdown(trigger) {
        const dropdown = trigger.closest('.dropdown');
        const content = dropdown.querySelector('.dropdown-content');
        
        // Close other dropdowns
        this.closeAllDropdowns();
        
        // Toggle current dropdown
        content.classList.toggle('hidden');
    }

    closeAllDropdowns() {
        document.querySelectorAll('.dropdown-content').forEach(content => {
            content.classList.add('hidden');
        });
    }

    // Tabs Component
    createTabs(element) {
        const tabs = Array.from(element.querySelectorAll('[data-tab]'));
        const panels = Array.from(element.querySelectorAll('[data-tab-panel]'));
        
        // Create tab navigation
        const tabNav = document.createElement('div');
        tabNav.className = 'tab-navigation flex border-b';
        
        tabs.forEach((tab, index) => {
            const tabButton = document.createElement('button');
            tabButton.className = `tab-trigger px-4 py-2 border-b-2 ${index === 0 ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-600 hover:text-gray-900'}`;
            tabButton.textContent = tab.dataset.tab;
            tabButton.dataset.tabTarget = tab.dataset.tab;
            tabNav.appendChild(tabButton);
        });
        
        element.prepend(tabNav);
        
        // Show first panel by default
        panels.forEach((panel, index) => {
            if (index !== 0) {
                panel.classList.add('hidden');
            }
        });
    }

    switchTab(trigger) {
        const tabContainer = trigger.closest('[data-component="tabs"]');
        const targetPanel = trigger.dataset.tabTarget;
        
        // Update tab buttons
        tabContainer.querySelectorAll('.tab-trigger').forEach(tab => {
            tab.classList.remove('border-blue-500', 'text-blue-600');
            tab.classList.add('border-transparent', 'text-gray-600');
        });
        trigger.classList.add('border-blue-500', 'text-blue-600');
        trigger.classList.remove('border-transparent', 'text-gray-600');
        
        // Update panels
        tabContainer.querySelectorAll('[data-tab-panel]').forEach(panel => {
            if (panel.dataset.tabPanel === targetPanel) {
                panel.classList.remove('hidden');
            } else {
                panel.classList.add('hidden');
            }
        });
    }

    // Accordion Component
    createAccordion(element) {
        const items = element.querySelectorAll('.accordion-item');
        
        items.forEach(item => {
            const header = item.querySelector('.accordion-header');
            const content = item.querySelector('.accordion-content');
            
            if (header && content) {
                header.classList.add('cursor-pointer', 'flex', 'justify-between', 'items-center', 'p-4', 'border-b');
                content.classList.add('hidden', 'p-4');
                
                // Add arrow icon
                if (!header.querySelector('.accordion-arrow')) {
                    const arrow = document.createElement('svg');
                    arrow.className = 'accordion-arrow w-5 h-5 transform transition-transform';
                    arrow.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>';
                    arrow.setAttribute('fill', 'none');
                    arrow.setAttribute('stroke', 'currentColor');
                    arrow.setAttribute('viewBox', '0 0 24 24');
                    header.appendChild(arrow);
                }
            }
        });
    }

    toggleAccordion(header) {
        const item = header.closest('.accordion-item');
        const content = item.querySelector('.accordion-content');
        const arrow = header.querySelector('.accordion-arrow');
        
        content.classList.toggle('hidden');
        if (arrow) {
            arrow.classList.toggle('rotate-180');
        }
    }

    // Notification Component
    createNotification(config = {}) {
        const type = config.type || 'info';
        const message = config.message || 'Notification';
        const duration = config.duration || 5000;
        const position = config.position || 'top-right';
        
        const typeClasses = {
            success: 'bg-green-500 text-white',
            error: 'bg-red-500 text-white',
            warning: 'bg-yellow-500 text-black',
            info: 'bg-blue-500 text-white'
        };
        
        const positionClasses = {
            'top-right': 'top-4 right-4',
            'top-left': 'top-4 left-4',
            'bottom-right': 'bottom-4 right-4',
            'bottom-left': 'bottom-4 left-4'
        };
        
        const notification = document.createElement('div');
        notification.className = `notification fixed ${positionClasses[position]} ${typeClasses[type]} p-4 rounded-lg shadow-lg z-50 max-w-sm`;
        notification.innerHTML = `
            <div class="flex items-center justify-between">
                <span>${message}</span>
                <button class="notification-close ml-4 text-current opacity-70 hover:opacity-100">×</button>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, duration);
        
        // Manual close
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });
        
        return notification;
    }

    // Progress Bar Component
    createProgressBar(element) {
        const progress = parseInt(element.dataset.progress) || 0;
        const color = element.dataset.color || 'blue';
        const showLabel = element.dataset.showLabel !== 'false';
        
        const progressHTML = `
            <div class="progress-container">
                ${showLabel ? `<div class="progress-label mb-2 text-sm font-medium text-gray-700">${progress}%</div>` : ''}
                <div class="progress-track bg-gray-200 rounded-full h-2">
                    <div class="progress-fill bg-${color}-500 h-2 rounded-full transition-all duration-300" style="width: ${progress}%"></div>
                </div>
            </div>
        `;
        
        element.innerHTML = progressHTML;
    }

    updateProgress(elementId, newProgress) {
        const element = document.getElementById(elementId);
        if (element) {
            const fill = element.querySelector('.progress-fill');
            const label = element.querySelector('.progress-label');
            
            if (fill) {
                fill.style.width = `${newProgress}%`;
            }
            if (label) {
                label.textContent = `${newProgress}%`;
            }
        }
    }

    // Form Validator Component
    createFormValidator(form) {
        const validator = {
            rules: {},
            messages: {},
            
            addRule(fieldName, rule, message) {
                if (!this.rules[fieldName]) this.rules[fieldName] = [];
                this.rules[fieldName].push(rule);
                this.messages[fieldName] = message;
            },
            
            validate() {
                let isValid = true;
                const formData = new FormData(form);
                
                for (let [fieldName, rules] of Object.entries(this.rules)) {
                    const value = formData.get(fieldName);
                    const field = form.querySelector(`[name="${fieldName}"]`);
                    
                    for (let rule of rules) {
                        if (!rule(value)) {
                            this.showError(field, this.messages[fieldName]);
                            isValid = false;
                            break;
                        } else {
                            this.clearError(field);
                        }
                    }
                }
                
                return isValid;
            },
            
            showError(field, message) {
                this.clearError(field);
                field.classList.add('border-red-500');
                
                const errorDiv = document.createElement('div');
                errorDiv.className = 'field-error text-red-500 text-sm mt-1';
                errorDiv.textContent = message;
                field.parentNode.appendChild(errorDiv);
            },
            
            clearError(field) {
                field.classList.remove('border-red-500');
                const existingError = field.parentNode.querySelector('.field-error');
                if (existingError) {
                    existingError.remove();
                }
            }
        };
        
        form.validator = validator;
        return validator;
    }

    // Utility methods
    show(element) {
        element.classList.remove('hidden');
    }

    hide(element) {
        element.classList.add('hidden');
    }

    toggle(element) {
        element.classList.toggle('hidden');
    }

    fadeIn(element, duration = 300) {
        element.style.opacity = '0';
        element.style.display = 'block';
        
        let start = performance.now();
        
        function animate(currentTime) {
            let elapsed = currentTime - start;
            let progress = elapsed / duration;
            
            if (progress < 1) {
                element.style.opacity = progress;
                requestAnimationFrame(animate);
            } else {
                element.style.opacity = '1';
            }
        }
        
        requestAnimationFrame(animate);
    }

    fadeOut(element, duration = 300) {
        let start = performance.now();
        let startOpacity = parseFloat(getComputedStyle(element).opacity);
        
        function animate(currentTime) {
            let elapsed = currentTime - start;
            let progress = elapsed / duration;
            
            if (progress < 1) {
                element.style.opacity = startOpacity * (1 - progress);
                requestAnimationFrame(animate);
            } else {
                element.style.opacity = '0';
                element.style.display = 'none';
            }
        }
        
        requestAnimationFrame(animate);
    }
}

// Initialize components system
document.addEventListener('DOMContentLoaded', () => {
    window.TorviaComponents = new TorviaComponents();
});

// Export for module usage
window.TorviaComponents = TorviaComponents;