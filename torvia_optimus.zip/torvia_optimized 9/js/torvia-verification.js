/**
 * Torvia Document Verification System
 * Handles document upload, validation, and verification processes
 */

class TorviaVerification {
    constructor() {
        this.uploadedFiles = new Map();
        this.verificationStatus = new Map();
        this.allowedFileTypes = [
            'application/pdf',
            'image/jpeg',
            'image/jpg', 
            'image/png',
            'image/gif'
        ];
        this.maxFileSize = 10 * 1024 * 1024; // 10MB
        this.requiredDocuments = [
            'business_license',
            'insurance_certificate',
            'tax_certificate',
            'id_document'
        ];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadExistingDocuments();
        this.initializeUploadAreas();
        this.checkVerificationStatus();
    }

    setupEventListeners() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('upload-trigger')) {
                this.triggerFileUpload(e.target);
            }
            
            if (e.target.classList.contains('remove-file-btn')) {
                this.removeFile(e.target.dataset.fileId);
            }
            
            if (e.target.classList.contains('submit-verification-btn')) {
                this.submitForVerification();
            }
            
            if (e.target.classList.contains('resubmit-btn')) {
                this.resubmitDocument(e.target.dataset.documentType);
            }
        });

        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('file-input')) {
                this.handleFileSelect(e.target);
            }
        });

        // Drag and drop support
        document.addEventListener('dragover', (e) => {
            if (e.target.classList.contains('upload-area')) {
                e.preventDefault();
                e.target.classList.add('drag-over');
            }
        });

        document.addEventListener('dragleave', (e) => {
            if (e.target.classList.contains('upload-area')) {
                e.target.classList.remove('drag-over');
            }
        });

        document.addEventListener('drop', (e) => {
            if (e.target.classList.contains('upload-area')) {
                e.preventDefault();
                e.target.classList.remove('drag-over');
                this.handleFileDrop(e.target, e.dataTransfer.files);
            }
        });
    }

    initializeUploadAreas() {
        document.querySelectorAll('.verification-upload-area').forEach(area => {
            this.renderUploadArea(area);
        });

        document.querySelectorAll('.verification-status-panel').forEach(panel => {
            this.renderStatusPanel(panel);
        });
    }

    renderUploadArea(container) {
        const documentType = container.dataset.documentType;
        const documentLabel = this.getDocumentLabel(documentType);
        const isRequired = this.requiredDocuments.includes(documentType);
        
        const html = `
            <div class="upload-section">
                <div class="document-header mb-4">
                    <h3 class="text-lg font-semibold flex items-center">
                        ${documentLabel}
                        ${isRequired ? '<span class="text-red-500 ml-1">*</span>' : ''}
                    </h3>
                    <p class="text-gray-600 text-sm">${this.getDocumentDescription(documentType)}</p>
                </div>
                
                <div class="upload-area border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors" 
                     data-document-type="${documentType}">
                    <div class="upload-icon mb-4">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/>
                        </svg>
                    </div>
                    
                    <div class="upload-text">
                        <p class="text-lg mb-2">Dokument hochladen</p>
                        <p class="text-gray-500 mb-4">Ziehen Sie Ihre Datei hierher oder klicken Sie zum Auswählen</p>
                        <button class="upload-trigger bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                                data-document-type="${documentType}">
                            Datei auswählen
                        </button>
                    </div>
                    
                    <input type="file" 
                           class="file-input hidden" 
                           accept=".pdf,.jpg,.jpeg,.png,.gif"
                           data-document-type="${documentType}">
                </div>
                
                <div class="file-requirements mt-4 text-sm text-gray-600">
                    <ul class="list-disc list-inside">
                        <li>Erlaubte Formate: PDF, JPG, PNG, GIF</li>
                        <li>Maximale Dateigröße: 10MB</li>
                        <li>Dokument muss gut lesbar sein</li>
                    </ul>
                </div>
                
                <div class="uploaded-files mt-6" data-document-type="${documentType}">
                    <!-- Uploaded files will be shown here -->
                </div>
            </div>
        `;
        
        container.innerHTML = html;
        this.displayExistingFiles(documentType);
    }

    renderStatusPanel(container) {
        const userId = container.dataset.userId;
        const verificationData = this.getVerificationData(userId);
        
        const html = `
            <div class="verification-status-content">
                <div class="status-header mb-6">
                    <h2 class="text-xl font-bold">Verifizierungsstatus</h2>
                    <div class="overall-status mt-2">
                        ${this.renderOverallStatus(verificationData)}
                    </div>
                </div>
                
                <div class="documents-status">
                    ${this.requiredDocuments.map(docType => 
                        this.renderDocumentStatus(docType, verificationData[docType])
                    ).join('')}
                </div>
                
                <div class="verification-actions mt-6">
                    ${this.renderVerificationActions(verificationData)}
                </div>
                
                <div class="verification-timeline mt-8">
                    <h3 class="text-lg font-semibold mb-4">Verifizierungsverlauf</h3>
                    ${this.renderVerificationTimeline(verificationData.timeline)}
                </div>
            </div>
        `;
        
        container.innerHTML = html;
    }

    renderOverallStatus(verificationData) {
        const completedDocs = this.requiredDocuments.filter(docType => 
            verificationData[docType]?.status === 'verified'
        ).length;
        
        const totalDocs = this.requiredDocuments.length;
        const percentage = (completedDocs / totalDocs) * 100;
        
        let statusText, statusClass, statusIcon;
        
        if (percentage === 100) {
            statusText = 'Vollständig verifiziert';
            statusClass = 'text-green-600';
            statusIcon = '✅';
        } else if (percentage >= 50) {
            statusText = 'Teilweise verifiziert';
            statusClass = 'text-yellow-600';
            statusIcon = '⏳';
        } else {
            statusText = 'Verifizierung ausstehend';
            statusClass = 'text-red-600';
            statusIcon = '❌';
        }
        
        return `
            <div class="status-badge flex items-center space-x-2">
                <span class="status-icon">${statusIcon}</span>
                <span class="${statusClass} font-semibold">${statusText}</span>
                <span class="text-gray-500">(${completedDocs}/${totalDocs} Dokumente)</span>
            </div>
            
            <div class="progress-bar mt-3">
                <div class="bg-gray-200 rounded-full h-2">
                    <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" 
                         style="width: ${percentage}%"></div>
                </div>
            </div>
        `;
    }

    renderDocumentStatus(documentType, docData) {
        const label = this.getDocumentLabel(documentType);
        const status = docData?.status || 'pending';
        const uploadDate = docData?.uploadDate;
        const reviewNotes = docData?.reviewNotes;
        
        let statusBadge, actionButton = '';
        
        switch (status) {
            case 'verified':
                statusBadge = '<span class="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">✅ Verifiziert</span>';
                break;
            case 'rejected':
                statusBadge = '<span class="bg-red-100 text-red-800 px-2 py-1 rounded text-sm">❌ Abgelehnt</span>';
                actionButton = `<button class="resubmit-btn text-blue-600 hover:text-blue-800 text-sm" data-document-type="${documentType}">Neu einreichen</button>`;
                break;
            case 'under_review':
                statusBadge = '<span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-sm">⏳ In Prüfung</span>';
                break;
            default:
                statusBadge = '<span class="bg-gray-100 text-gray-800 px-2 py-1 rounded text-sm">⚪ Ausstehend</span>';
        }
        
        return `
            <div class="document-status-item border-b pb-4 mb-4">
                <div class="flex justify-between items-start">
                    <div class="document-info">
                        <h4 class="font-medium">${label}</h4>
                        ${uploadDate ? `<p class="text-sm text-gray-500">Hochgeladen: ${this.formatDate(uploadDate)}</p>` : ''}
                        ${reviewNotes ? `<p class="text-sm text-red-600 mt-1">${reviewNotes}</p>` : ''}
                    </div>
                    <div class="document-actions">
                        ${statusBadge}
                        ${actionButton}
                    </div>
                </div>
            </div>
        `;
    }

    renderVerificationActions(verificationData) {
        const hasUnsubmittedFiles = this.hasUnsubmittedFiles();
        const allRequiredSubmitted = this.allRequiredDocumentsSubmitted();
        
        if (!allRequiredSubmitted) {
            return `
                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <p class="text-yellow-800">Bitte laden Sie alle erforderlichen Dokumente hoch, bevor Sie die Verifizierung einreichen.</p>
                </div>
            `;
        }
        
        if (hasUnsubmittedFiles) {
            return `
                <button class="submit-verification-btn bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 w-full">
                    Zur Verifizierung einreichen
                </button>
            `;
        }
        
        return `
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p class="text-blue-800">Alle Dokumente wurden eingereicht. Die Überprüfung dauert normalerweise 2-3 Werktage.</p>
            </div>
        `;
    }

    triggerFileUpload(trigger) {
        const documentType = trigger.dataset.documentType;
        const fileInput = document.querySelector(`input[data-document-type="${documentType}"]`);
        if (fileInput) {
            fileInput.click();
        }
    }

    handleFileSelect(input) {
        const files = input.files;
        const documentType = input.dataset.documentType;
        
        for (let file of files) {
            this.processFile(file, documentType);
        }
        
        // Clear input for re-upload
        input.value = '';
    }

    handleFileDrop(area, files) {
        const documentType = area.dataset.documentType;
        
        for (let file of files) {
            this.processFile(file, documentType);
        }
    }

    processFile(file, documentType) {
        // Validate file
        const validation = this.validateFile(file);
        if (!validation.valid) {
            this.showError(validation.error);
            return;
        }
        
        // Generate file ID
        const fileId = `${documentType}_${Date.now()}`;
        
        // Create file object
        const fileData = {
            id: fileId,
            file: file,
            documentType: documentType,
            name: file.name,
            size: file.size,
            type: file.type,
            uploadDate: new Date().toISOString(),
            status: 'uploaded'
        };
        
        // Store file
        this.uploadedFiles.set(fileId, fileData);
        
        // Update display
        this.displayFile(fileData);
        
        // Save to localStorage
        this.saveUploadedFiles();
        
        this.showSuccess(`${file.name} erfolgreich hochgeladen`);
    }

    validateFile(file) {
        if (!this.allowedFileTypes.includes(file.type)) {
            return {
                valid: false,
                error: 'Dateityp nicht erlaubt. Erlaubte Formate: PDF, JPG, PNG, GIF'
            };
        }
        
        if (file.size > this.maxFileSize) {
            return {
                valid: false,
                error: 'Datei zu groß. Maximale Größe: 10MB'
            };
        }
        
        return { valid: true };
    }

    displayFile(fileData) {
        const container = document.querySelector(`div[data-document-type="${fileData.documentType}"].uploaded-files`);
        if (!container) return;
        
        const fileHTML = `
            <div class="uploaded-file border rounded-lg p-4 mb-3" data-file-id="${fileData.id}">
                <div class="flex items-center justify-between">
                    <div class="file-info flex items-center space-x-3">
                        <div class="file-icon">
                            ${this.getFileIcon(fileData.type)}
                        </div>
                        <div class="file-details">
                            <p class="font-medium">${fileData.name}</p>
                            <p class="text-sm text-gray-500">${this.formatFileSize(fileData.size)} • ${this.formatDate(fileData.uploadDate)}</p>
                        </div>
                    </div>
                    <div class="file-actions flex items-center space-x-2">
                        <button class="preview-file-btn text-blue-600 hover:text-blue-800 text-sm">
                            Vorschau
                        </button>
                        <button class="remove-file-btn text-red-600 hover:text-red-800 text-sm" 
                                data-file-id="${fileData.id}">
                            Entfernen
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', fileHTML);
    }

    removeFile(fileId) {
        this.uploadedFiles.delete(fileId);
        
        const fileElement = document.querySelector(`[data-file-id="${fileId}"]`);
        if (fileElement) {
            fileElement.remove();
        }
        
        this.saveUploadedFiles();
        this.showSuccess('Datei entfernt');
    }

    submitForVerification() {
        const files = Array.from(this.uploadedFiles.values());
        
        // Check if all required documents are uploaded
        const missingDocs = this.requiredDocuments.filter(docType => {
            return !files.some(file => file.documentType === docType);
        });
        
        if (missingDocs.length > 0) {
            this.showError('Bitte laden Sie alle erforderlichen Dokumente hoch');
            return;
        }
        
        // Submit files
        this.processVerificationSubmission(files);
    }

    processVerificationSubmission(files) {
        // Simulate API submission
        files.forEach(file => {
            file.status = 'submitted';
            file.submissionDate = new Date().toISOString();
        });
        
        // Update verification status
        this.updateVerificationStatus(files);
        
        // Show success message
        this.showSuccess('Dokumente erfolgreich zur Verifizierung eingereicht');
        
        // Refresh display
        setTimeout(() => {
            location.reload();
        }, 2000);
    }

    updateVerificationStatus(files) {
        const verificationData = this.getVerificationData() || {};
        
        files.forEach(file => {
            verificationData[file.documentType] = {
                status: 'under_review',
                uploadDate: file.uploadDate,
                submissionDate: file.submissionDate,
                filename: file.name
            };
        });
        
        // Add timeline entry
        if (!verificationData.timeline) verificationData.timeline = [];
        verificationData.timeline.push({
            date: new Date().toISOString(),
            action: 'documents_submitted',
            description: 'Dokumente zur Überprüfung eingereicht'
        });
        
        localStorage.setItem('torvia_verification', JSON.stringify(verificationData));
    }

    // Utility Methods
    getDocumentLabel(documentType) {
        const labels = {
            business_license: 'Gewerbeschein',
            insurance_certificate: 'Haftpflichtversicherung',
            tax_certificate: 'Steuerbescheinigung',
            id_document: 'Personalausweis'
        };
        return labels[documentType] || documentType;
    }

    getDocumentDescription(documentType) {
        const descriptions = {
            business_license: 'Gültiger Gewerbeschein oder Handwerksausweis',
            insurance_certificate: 'Nachweis über Betriebshaftpflichtversicherung',
            tax_certificate: 'Aktuelle Steuernummer oder Umsatzsteuer-ID',
            id_document: 'Gültiger Personalausweis oder Reisepass'
        };
        return descriptions[documentType] || '';
    }

    getFileIcon(fileType) {
        if (fileType === 'application/pdf') {
            return '📄';
        } else if (fileType.startsWith('image/')) {
            return '🖼️';
        }
        return '📎';
    }

    formatFileSize(bytes) {
        const units = ['B', 'KB', 'MB', 'GB'];
        let size = bytes;
        let unitIndex = 0;
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return `${size.toFixed(1)} ${units[unitIndex]}`;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('de-DE');
    }

    showSuccess(message) {
        if (window.TorviaComponents) {
            window.TorviaComponents.createNotification({
                type: 'success',
                message: message
            });
        }
    }

    showError(message) {
        if (window.TorviaComponents) {
            window.TorviaComponents.createNotification({
                type: 'error',
                message: message
            });
        }
    }

    saveUploadedFiles() {
        const filesData = {};
        this.uploadedFiles.forEach((file, id) => {
            filesData[id] = {
                id: file.id,
                documentType: file.documentType,
                name: file.name,
                size: file.size,
                type: file.type,
                uploadDate: file.uploadDate,
                status: file.status
            };
        });
        localStorage.setItem('torvia_uploaded_files', JSON.stringify(filesData));
    }

    loadExistingDocuments() {
        const savedFiles = localStorage.getItem('torvia_uploaded_files');
        if (savedFiles) {
            const filesData = JSON.parse(savedFiles);
            Object.values(filesData).forEach(fileData => {
                this.uploadedFiles.set(fileData.id, fileData);
            });
        }
    }

    displayExistingFiles(documentType) {
        const files = Array.from(this.uploadedFiles.values())
            .filter(file => file.documentType === documentType);
        
        files.forEach(file => {
            this.displayFile(file);
        });
    }

    getVerificationData(userId = null) {
        const saved = localStorage.getItem('torvia_verification');
        return saved ? JSON.parse(saved) : {};
    }

    hasUnsubmittedFiles() {
        return Array.from(this.uploadedFiles.values())
            .some(file => file.status === 'uploaded');
    }

    allRequiredDocumentsSubmitted() {
        const files = Array.from(this.uploadedFiles.values());
        return this.requiredDocuments.every(docType => 
            files.some(file => file.documentType === docType)
        );
    }

    checkVerificationStatus() {
        // Periodic check for verification status updates
        setInterval(() => {
            this.refreshVerificationStatus();
        }, 30000); // Check every 30 seconds
    }

    refreshVerificationStatus() {
        // In a real application, this would make an API call
        // For now, we'll simulate status updates
    }

    renderVerificationTimeline(timeline = []) {
        if (!timeline || timeline.length === 0) {
            return '<p class="text-gray-500">Noch keine Aktivitäten</p>';
        }
        
        return timeline.map(entry => `
            <div class="timeline-item flex items-start space-x-3 mb-3">
                <div class="timeline-dot w-3 h-3 bg-blue-500 rounded-full mt-1"></div>
                <div class="timeline-content">
                    <p class="font-medium">${entry.description}</p>
                    <p class="text-sm text-gray-500">${this.formatDate(entry.date)}</p>
                </div>
            </div>
        `).join('');
    }
}

// Initialize verification system when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.verification-upload-area, .verification-status-panel')) {
        window.TorviaVerification = new TorviaVerification();
    }
});

// Export for module usage
window.TorviaVerification = TorviaVerification;